import "./App.css";
import React, { useState, useEffect } from "react";
import { nanoid } from "nanoid";

function App() {

  const [userArray, setUserArray] = useState(
    [
      {
        id:1,
        name:"Admin",
        email:"admin@gmail.com",
        password:"1234",
        role:"admin"
      }
    ]
  )

  const [loginemail, setLoginEmail] = useState("")
  const [loginpassword, setLoginPass] = useState("")
  const [loggedinUserDetails, setLogginInUserDetail] = useState({})
  const [newUserDetails, setnewUserDetails] = useState({
    email:"",
    password:"",
    role:"user",
    name:""
  })

  const [phase, setPhase] = useState(0)
  // 0 - login
  // 1 -register
  // 2 - dashboard

  useEffect(() => {
    
  }, []);

  function validateEmail(email) 
    {
        var re = /\S+@\S+\.\S+/;
        return re.test(email);
    }

  const handleLoginSubmit = () => {
    if(!loginemail){
      return alert("Email is Required")
    }
    if(!validateEmail(loginemail)){
      return alert("Email is Not Valid")
    }
    if(!loginpassword){
      return alert("Password is Required")
    }
    let userObj = userArray.find(x=>x['email'] === loginemail)
    if(userObj){
      if(userObj['password'] === loginpassword){
        alert("Login Successfully")
        let tempUserObj = copyVariable(userObj)
        delete tempUserObj['password']
        setLogginInUserDetail(tempUserObj)
        setPhase(2)
      }else{
        alert("Either Email or Password is Incorrect")
      }
    }else{
      return alert("Either Email or Password is Incorrect")
    }
  }

  function copyVariable(variable){
    return variable
  }

  const handleNewUserAdd = () => {
    let newUserObj = copyVariable(newUserDetails)
    if(!newUserObj['email']){
      return alert("Email is Required")
    }
    if(!validateEmail(newUserObj['email'])){
      return alert("Email is Not Valid")
    }
    if(!newUserObj['password']){
      return alert("Pass is Required")
    }
    if(!newUserObj['name']){
      return alert("Name is Required")
    }
    if(userArray.find(x=>x['email'] === newUserObj['email'])){
      return alert("User is Already Added into Database")
    }
    newUserObj['id'] = nanoid()
    setUserArray(
      [
        ...userArray,
        ...[newUserObj]
      ]
    )
    setnewUserDetails(
      {
        email:"",
        password:"",
        role:"user",
        name:""
      }
    )
    alert("User Added into List")
  }

  const handleLogout = () => {
    setLogginInUserDetail({})
    setPhase(0)
    setLoginEmail("")
    setLoginPass("")
  }

  return (
    <div className="App">
        {phase === 0 && <>
        
        <h1>Login</h1>
        <br/>
        <label>Email : </label>
        <input name='email' type="email" autoComplete="off" value={loginemail} onChange={(e)=>setLoginEmail(e.target.value)} />
        <br/>
        <label>Password : </label>
        <input name='password' type="password" autoComplete="off" value={loginpassword} onChange={(e)=>setLoginPass(e.target.value)} />
          <br/>
          <button type="submit" onClick={handleLoginSubmit}>submit</button>
        </>}
        {phase === 2 && <>
          Welcome {loggedinUserDetails['name']}
          <br/>
          <button type="submit" onClick={handleLogout}>Logout</button>
          <br/>
          {loggedinUserDetails['role'] === 'admin' && <><h2>Add a New User</h2>
          <br/>
          <label>Name : </label>
        <input name='name' type="text" autoComplete="off" value={newUserDetails['name']} onChange={(e)=>setnewUserDetails({
          ...newUserDetails,
          name:e.target.value
        })} />
        <br/>
        <label>Email : </label>
        <input name='email' type="email" autoComplete="off" value={newUserDetails['email']} onChange={(e)=>setnewUserDetails({
          ...newUserDetails,
          email:e.target.value
        })} />
        <br/>
        <label>Password : </label>
        <input name='password' type="password" autoComplete="off" value={newUserDetails['password']} onChange={(e)=>setnewUserDetails({
          ...newUserDetails,
          password:e.target.value
        })} />
          <br/>
          <button type="submit" onClick={handleNewUserAdd}>submit</button></>}
        </>}
    </div>
  );
}

export default App;


// Gender
// Male name = "gender"
// Female name = "gender"


// each post should contain
// details regrading the post, created at, userId

// nodejs

// reactjs is divided into 2 parts 

// one is static -> npm run build -> move build folder to cloud/hosting/aws/ : what we learnt above // not suitable for seo
// anohter one is server side -> npm run start in the cloud : Nextjs, gatsby. - very good for application having more than 50 pages to avoid multiple deployments
// ssr : server side rendering is goood for seo also